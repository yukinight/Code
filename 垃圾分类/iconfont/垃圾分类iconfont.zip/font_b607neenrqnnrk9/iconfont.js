;(function(window) {

var svgSprite = '<svg>' +
  ''+
    '<symbol id="icon-guanbi" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M521.9359 508.1354m-441.7966 0a431.442 431.442 0 1 0 883.5932 0 431.442 431.442 0 1 0-883.5932 0Z"  ></path>'+
      ''+
      '<path d="M567.9462 409.556l64.853-62.805c0 0 23.7015-16.9277 40.0855-1.2268s54.8055 34.6778 27.4985 70.1757l-108.544 106.496L696.9702 629.374c0 0 10.923 16.385-2.048 33.451s-40.7613 58.7848-66.219 36.181c-31.2801-27.7729-104.448-109.909-104.448-109.909l-109.396 105.472c0 0-24.193 27.178-52.8814-2.0572-29.3069-29.866-34.7832-46.8931-20.3346-65.5268 16.2939-21.0145 112.64-107.52 112.64-107.52l-108.544-109.568c0 0-11.946-22.869 5.804-41.984 17.748-19.115 36.181-42.326 61.44-23.211 25.258 19.115 109.5639 109.227 109.5639 109.227L567.9462 409.556z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-iconfontyuan" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M512.010 292.501c-121.23 0-219.505 98.261-219.505 219.498 0 121.216 98.276 219.499 219.506 219.499 121.22 0 219.487-98.284 219.487-219.499 0.001-121.237-98.264-219.498-219.487-219.498z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-cha" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M607.491353 513.260713 936.024831 184.392614c26.41665-26.41665 26.41665-69.27783 0-95.777367-26.41358-26.41665-69.194942-26.41665-95.608521 0L511.796874 417.565211 182.762999 88.115873c-26.086122-26.000164-68.200288-26.000164-94.200452 0-26.083052 26.000164-26.083052 68.283176 0 94.28334l329.11574 329.367473-328.203974 328.45059c-26.41358 26.499537-26.41358 69.360717 0 95.77839 26.41665 26.415626 69.281923 26.415626 95.694479 0l328.120063-328.451614 325.545424 325.874929c26.082028 26.000164 68.200288 26.000164 94.200452 0 26.000164-26.082028 26.000164-68.279083 0-94.28334L607.491353 513.260713z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-sousuobanjisousuo" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M904.182101 861.492836 730.880079 687.09997c47.118134-61.885466 75.143421-139.275044 75.143421-223.26904 0-202.924689-163.475212-367.429347-365.137141-367.429347-201.657836 0-365.132024 164.503635-365.132024 367.429347C75.755358 666.762783 239.229546 831.265394 440.887382 831.265394c86.157265 0 165.328419-30.045293 227.77875-80.263022L841.321424 924.754648c8.6848 8.730848 20.050662 13.095249 31.435966 13.095249 11.364839 0 22.750143-4.370541 31.42471-13.095249C921.543513 907.279648 921.543513 878.968859 904.182101 861.492836L904.182101 861.492836 904.182101 861.492836zM245.556649 660.396795c-52.173267-52.504818-80.908728-122.30965-80.908728-196.564841 0-74.250074 28.735461-144.053883 80.908728-196.559725 52.17736-52.499701 121.54524-81.417311 195.330734-81.417311 73.79061 0 143.157467 28.922726 195.325617 81.417311 52.17736 52.506864 80.913844 122.30965 80.913844 196.559725 0 74.255191-28.736485 144.060023-80.903611 196.564841-52.178383 52.496631-121.54524 81.412195-195.33585 81.412195C367.101889 741.80899 297.732985 712.892403 245.556649 660.396795L245.556649 660.396795 245.556649 660.396795zM245.556649 660.396795"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-triangle" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M933.875 301.059l-421.898 421.803-421.852-421.803h843.75z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-arrowdown" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M490.897 723.696c0.973 0.486 1.824 1.338 2.797 1.703 17.758 8.514 39.651 5.717 53.882-9.365l325.116-343.725c17.758-18.731 16.907-48.287-1.824-66.045s-48.287-16.907-66.045 1.824l-291.79 308.453-296.047-307.236c-17.881-18.609-47.436-19.096-66.045-1.216-9.487 9.122-14.351 21.407-14.352 33.57 0 11.676 4.378 23.353 13.137 32.353l328.278 340.563c0.608 0.608 1.581 0.851 2.189 1.581 0.487 0.487 0.851 0.973 1.338 1.581 2.797 2.797 6.203 4.135 9.365 5.959v0zM490.897 723.696z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
    '<symbol id="icon-jiantouyoujiantou" viewBox="0 0 1024 1024">'+
      ''+
      '<path d="M300.304 490.897c-0.486 0.973-1.338 1.824-1.703 2.797-8.514 17.758-5.717 39.651 9.365 53.882l343.725 325.116c18.731 17.758 48.287 16.907 66.045-1.824s16.907-48.287-1.824-66.045l-308.453-291.79 307.236-296.047c18.609-17.881 19.096-47.436 1.216-66.045-9.122-9.487-21.407-14.351-33.57-14.352-11.676 0-23.353 4.378-32.353 13.137l-340.563 328.278c-0.608 0.608-0.851 1.581-1.581 2.189-0.487 0.487-0.973 0.851-1.581 1.338-2.797 2.797-4.135 6.203-5.959 9.365v0zM300.304 490.897z"  ></path>'+
      ''+
    '</symbol>'+
  ''+
'</svg>'
var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
var shouldInjectCss = script.getAttribute("data-injectcss")

/**
 * document ready
 */
var ready = function(fn){
  if(document.addEventListener){
      document.addEventListener("DOMContentLoaded",function(){
          document.removeEventListener("DOMContentLoaded",arguments.callee,false)
          fn()
      },false)
  }else if(document.attachEvent){
     IEContentLoaded (window, fn)
  }

  function IEContentLoaded (w, fn) {
      var d = w.document, done = false,
      // only fire once
      init = function () {
          if (!done) {
              done = true
              fn()
          }
      }
      // polling for no errors
      ;(function () {
          try {
              // throws errors until after ondocumentready
              d.documentElement.doScroll('left')
          } catch (e) {
              setTimeout(arguments.callee, 50)
              return
          }
          // no errors, fire

          init()
      })()
      // trying to always fire before onload
      d.onreadystatechange = function() {
          if (d.readyState == 'complete') {
              d.onreadystatechange = null
              init()
          }
      }
  }
}

/**
 * Insert el before target
 *
 * @param {Element} el
 * @param {Element} target
 */

var before = function (el, target) {
  target.parentNode.insertBefore(el, target)
}

/**
 * Prepend el to target
 *
 * @param {Element} el
 * @param {Element} target
 */

var prepend = function (el, target) {
  if (target.firstChild) {
    before(el, target.firstChild)
  } else {
    target.appendChild(el)
  }
}

function appendSvg(){
  var div,svg

  div = document.createElement('div')
  div.innerHTML = svgSprite
  svg = div.getElementsByTagName('svg')[0]
  if (svg) {
    svg.setAttribute('aria-hidden', 'true')
    svg.style.position = 'absolute'
    svg.style.width = 0
    svg.style.height = 0
    svg.style.overflow = 'hidden'
    prepend(svg,document.body)
  }
}

if(shouldInjectCss && !window.__iconfont__svg__cssinject__){
  window.__iconfont__svg__cssinject__ = true
  try{
    document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
  }catch(e){
    console && console.log(e)
  }
}

ready(appendSvg)


})(window)
